# APB4VIP-4-CMSDK

## 简介
该项目是一个对Corex-M0仿真核中用到的、使用APB4作为接口的外设进行验证的项目。编写VIP以加速验证过程。

## 文件结构
+ dut：设计代码
+ sim：仿真脚本及Makefile