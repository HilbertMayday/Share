# AHBL2APB-Verification

##  简介

这是一个验证AHBL协议到APB协议的转换桥的验证项目。未使用现成的VIP，而是使用自己编写的VIP进行验证过程。验证结构为标准的UVM验证结构。DUT代码来源于Cortex-M0的开源项目：[Cortex-M0的Verilog仿真核](https://github.com/ForrestBlue/cortexm0ds/tree/master)。

## 验证环境

验证语言：SystemVerilog
验证方法学：UVM
编译：VCS
仿真：VCS
波形查看：DVE
覆盖率收集：DVE

## 文件夹

+ rtl：设计文件

+ sim：仿真文件，使用VCS进行仿真

+ uvm：UVM验证相关文件
++ cov：覆盖率相关文件
++ env：UVM中，属于env层级的文件
++ seq_lib：供测试用例使用的sequence
++ tb：testbench和interface
++ test：测试用例文件
++ vip_lib：自己编写的VIP
+++ ahbl：AHBL VIP
+++ apb_v3：APB VIP，其中APB符合APB3的时序要求

## 覆盖率收集情况

对DUT而言，回归测试的结果如下：

+ Line：99%，只有一行未收集到
+ Toggle：92%
+ FSM：58%
+ Branch：93%

一些burst类型没有被覆盖到。需要考虑更加合理的sequence库去覆盖所有的激励类型！

---

# AHBL2APB-Verification(English)

## Introduction

This is a verification project for the conversion bridge from AHBL protocol to APB protocol. Not using existing VIP, but using a VIP written by oneself for the verification process. The verification structure is a standard UVM verification structure.

## Verification Environment

Programming language: SystemVerilog
Verification method: UVM
Compile: VCS
Simulation: VCS
Waveform: DVE
Coverage collection: DVE

## Folder

+ rtl: design files

+ sim: simulation scripts, running with VCS

+ uvm: UVM files
++ cov: coverage files
++ env: files belonging to UVM env level
++ seq_lib: sequences for testcases
++ tb: testbench和interface
++ test: testcase files
++ vip_lib: VIP written by oneself
+++ ahbl: AHBL VIP
+++ apb_v3: APB VIP, which APB meets the timing requirements of APB3

## Coverage situation

For DUT, regression test results:

+ Line: 99%, only one cannot cover
+ Toggle: 92%
+ FSM: 58%
+ Branch: 93%

Some burst types don't cover. Consider more reasonble sequence library to cover all transaction type!
